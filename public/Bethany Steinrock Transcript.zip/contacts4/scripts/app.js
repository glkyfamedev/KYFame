app = angular.module("todoList3", []);

app.controller('mainCtrl', function($scope, $http) {
  
   $scope.msg = 'test';
  
   $http.get("getContacts.php")
     .then(function (response) {
	    $scope.contacts = response.data;  
     });
  
   
   $scope.addContact = function() {
	  
	  if($scope.newName) {
		 //name = encodeURI($scope.newName);
		  params = "sql=insert&name="+$scope.newName + "&" + "phone="+$scope.newPhone;
		  url = "getContacts.php?" + params;
	      $http.get(url)
             .then(function (response) {
	             $scope.contacts = response.data;
			 }, function myError(response) {
                 $scope.msg = response.statusText;
          });	  
	  }
	  
	  //$scope.msg = url;
	  $scope.newName = "";
	  $scope.newPhone = "";
  };
  
   $scope.deleteContact = function(contact, $index) { 
     
	  params = "sql=delete&name=" + contact.name;
	  url = "getContacts.php?" + params;
	  //$scope.msg = url;
	
	  $http.get(url) 
         .then(function (response) {
	          $scope.contacts = response.data;
			  //$scope.msg = response.data;
	     });
   };
  
});
