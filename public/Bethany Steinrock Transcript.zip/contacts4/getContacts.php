<?php
    //header("Access-Control-Allow-Origin: *");
    //header("Content-Type: application/json; charset=UTF-8");

    $dsn = "mysql:dbname=contacts4; charset=utf8"; 
	$username = "root"; 
	$password = ""; 

	try { 
    	$conn = new PDO( $dsn, $username, $password ); 
    	$conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION ); 
	}  
	catch ( PDOException $e ) { 
		echo "Connection failed: " . $e->getMessage(); 
	} 
	
	
	if ($_SERVER['REQUEST_METHOD'] == 'GET') {
		   
		 if(isset($_GET['sql']) && $_GET['sql']=='insert' && isset($_GET['name'])) {
			  $n = $_GET['name'];
			  $p = $_GET['phone'];
			  $sql = "INSERT INTO contacts VALUES(Null, ?, ?)";
			  $st = $conn->prepare($sql);
			  $st->execute(array($n, $p));  // prepared statement
		 }
			
		 if(isset($_GET['sql']) && $_GET['sql']=='delete' && isset($_GET['name'])) {
			  $n = $_GET['name'];
			  //$p = $_GET['phone'];
			  $sql = "DELETE FROM contacts WHERE name = '$n'";
			  $r = $conn->exec( $sql );
		 }
		
		
	
  	    $sql = "SELECT name, phone FROM contacts"; 
	    $rows = $conn->query( $sql );      // get the table rows 
	
	    $list_items = $rows->fetchAll(PDO::FETCH_ASSOC);
	
	    //$output = '{"records":['. $all_items .']}';
        $output = json_encode($list_items);  // creates an array of row objects
        echo($output);
	
	}
?>