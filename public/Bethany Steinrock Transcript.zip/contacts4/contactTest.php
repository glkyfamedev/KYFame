<?php

try {
	$request_data = file_get_contents("php://input");
	
	$jsonDataDecoded     = json_decode($request_data, true);  //true = array, false -> object
	// $jsonDataDecoded = data
	
	//$message            = $dataJsonDecode['message'];
    //echo $message;     //'Hello world'
    //echo $dataJsonDecode['message'];
	
	$dsn = "mysql:dbname=contacts4; charset=utf8"; 
	$username = "root"; 
	$password = ""; 


    $conn = new PDO( $dsn, $username, $password ); 
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    
    $conn->beginTransaction();   // begin the transaction
   	
	// intentionally delete all records. would ot be wise to do with a large table
	$conn->exec("Delete From my_jobs");  
	// replace all table data with 
	 foreach ( $jsonDataDecoded as $row ) { 
	     $n =  $todoName = $row['job'];
         $d =  $todoDone = $row['complete'];
	     $conn->exec("INSERT INTO my_jobs VALUES (Null, '$n', $d)");
  	 } 
   
    $conn->commit();   // commit the transaction
    echo "New records created successfully";
    }
catch(PDOException $e)
    {
    // roll back the transaction if something failed
    $conn->rollback();
    echo "Error: " . $e->getMessage();
    }

$conn = null;
	
	
	
	 
	// array approach --------------------
	
	//echo $dataJsonDecoded[0]['message'];
	//echo $dataJsonDecoded[1]['month'];
	
	/*   raw array data
	print_r($dataJsonDecoded);  // looks like this
	"data":"Array
	      (
		    [0] => Array ( [message] => Hello world )
		    [1] => Array ( [month] => October )
		   )"
	------------  end array approach */ 
	
	



/*
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");


    $dsn = "mysql:dbname=todoList; charset=utf8"; 
	$username = "root"; 
	$password = ""; 

	try { 
    	$conn = new PDO( $dsn, $username, $password ); 
    	$conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION ); 
	}  
	catch ( PDOException $e ) { 
		echo "Connection failed: " . $e->getMessage(); 
	} 
	
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		echo "got post";
		$todo_data = $_POST['data'];
		$todo_data = json_decode($todo_data);
		//var_dump($todo_data);
		
	}
	else if ($_SERVER['REQUEST_METHOD'] == 'GET') {
		echo 'get request';
  	    $sql = "SELECT name, completed FROM my_jobs"; 
	    $rows = $conn->query( $sql );      // get the table rows 
	
	    try {
		    foreach ( $rows as $row ) { 
			    $item1 = array("name"=>$row['name'], "completed"=>$row['completed']);
     		    $all_items[] = $item1;
  		    } 
	    } 
		catch ( PDOException $e ) { 
            echo "Query failed: " . $e->getMessage(); 
	    } 
	
	    //$output = '{"records":['. $all_items .']}';
       $output = json_encode($all_items);  // creates an array of row objects
       echo($output);
	
	}
	else {
		//
	}
  */
  
  
  /*
  
   $outp = "";
   $item1 = array(
       "name" => "Waffels", 
       "category" => "BREAKFAST",
       "portion" => "2 ea." 
   );
   $item2 = array(
       "name" => "Bagels", 
       "category" => "BREAKFAST",
       "portion" => "1 ea." 
   );
   
   $items = json_encode($item1) . ", " . json_encode($item2);
   $output = '{"records":['. $items .']}';
   //$outp = json_encode($record);

   echo($output);
   */
   
   
   /*
   while($rs = $result->fetch_array(MYSQLI_ASSOC)) {
      if ($outp != "") {
         $outp .= ",";
      }
      $outp .= '{"Name":"' . $rs["CompanyName"] . '",';
      $outp .= '"City":"' . $rs["City"] . '",';
      $outp .= '"Country":"'. $rs["Country"] . '"}'; 
   }

   $outp ='{"records":['.$outp.']}';
   */
?>
